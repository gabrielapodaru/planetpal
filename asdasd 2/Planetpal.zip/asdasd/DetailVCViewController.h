//
//  DetailVCViewController.h
//  SustainabilityAppDesign
//
//  Created by Podaru, Maria-Gabriela on 20/04/2023.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailVCViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
