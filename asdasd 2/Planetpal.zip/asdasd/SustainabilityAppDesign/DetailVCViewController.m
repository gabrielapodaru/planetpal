//
//  DetailVCViewController.m
//  SustainabilityAppDesign
//
//  Created by Podaru, Maria-Gabriela on 20/04/2023.
//

#import "DetailVCViewController.h"

@interface DetailVCViewController ()

@end

@implementation DetailVCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
