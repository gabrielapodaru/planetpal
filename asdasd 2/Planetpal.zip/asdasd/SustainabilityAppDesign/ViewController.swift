//
//  ViewController.swift
//  SustainabilityAppDesign
//
//  Created by Gabriela Podaru on 13/02/2023.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

